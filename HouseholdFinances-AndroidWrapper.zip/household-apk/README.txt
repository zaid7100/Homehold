Household Finances Android wrapper

This APK wrapper opens the published Replit app inside an Android WebView.
The backend/database remain on the Replit deployment, so the phone needs internet access.

App URL:
https://classic-generous-arguments--zaidnohammed.replit.app

Build:
gradle :app:assembleDebug

The included GitHub Actions workflow can build the APK automatically.
